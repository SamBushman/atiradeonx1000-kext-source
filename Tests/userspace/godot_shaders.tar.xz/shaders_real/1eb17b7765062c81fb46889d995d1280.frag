








vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2D(tex,  vec2(x_coord, y_coord),  0.0);
}




















uniform  mat4 camera_matrix;

uniform  mat4 camera_inverse_matrix;
uniform  mat4 projection_matrix;
uniform  mat4 projection_inverse_matrix;

uniform  mat4 world_transform;

uniform  float time;
uniform  int view_index;

uniform  vec2 viewport_size;










uniform vec4 bg_color;
uniform float bg_energy;

uniform float ambient_sky_contribution;
uniform vec4 ambient_color;
uniform float ambient_energy;







varying  vec3 vertex_interp;
varying vec3 normal_interp;


varying vec4 color_interp;



varying vec3 view_interp;

vec3 F0(float metallic, float specular, vec3 albedo) {
	float dielectric = 0.16 * specular * specular;
	
	
	return mix(vec3(dielectric), albedo, vec3(metallic));
}


uniform bool m_orthogonal;
uniform  float m_grid_size;









void main() {
	 vec3 vertex = vertex_interp;
	vec3 view = -normalize(vertex_interp);
	vec3 albedo = vec3(1.0);
	vec3 transmission = vec3(0.0);
	float metallic = 0.0;
	float specular = 0.5;
	vec3 emission = vec3(0.0);
	float roughness = 1.0;
	float rim = 0.0;
	float rim_tint = 0.0;
	float clearcoat = 0.0;
	float clearcoat_gloss = 0.0;
	float anisotropy = 0.0;
	vec2 anisotropy_flow = vec2(1.0, 0.0);
	float sss_strength = 0.0; 
	
	
	float m_DEPTH = 0.0;

	float alpha = 1.0;
	float side = 1.0;

	float specular_blob_intensity = 1.0;


	vec3 binormal = vec3(0.0);
	vec3 tangent = vec3(0.0);
	vec3 normal = normalize(normal_interp) * side;

	float normaldepth = 1.0;



	{
		
{
	albedo = color_interp.rgb;
	vec3 m_dir = (m_orthogonal ? -vec3(0.0,0.0,1.0) : view);
	float m_angle_fade = abs(dot(m_dir, normal));
	m_angle_fade = smoothstep(0.05, 0.2, m_angle_fade);
	vec3 m_world_pos = (camera_matrix * vec4(vertex.xyz, 1.0)).xyz;
	vec3 m_world_normal = (camera_matrix * vec4(normal, 0.0)).xyz;
	vec3 m_camera_world_pos = camera_matrix[3].xyz;
	vec3 m_camera_world_pos_on_plane = (m_camera_world_pos * (1.0 - m_world_normal));
	float m_dist_fade = (1.0 - (distance(m_world_pos, m_camera_world_pos_on_plane) / m_grid_size));
	m_dist_fade = smoothstep(0.02, 0.3, m_dist_fade);
	alpha = ((color_interp.a * m_dist_fade) * m_angle_fade);
}


		
	}


	normal = normalize(normal);

	vec3 N = normal;

	vec3 specular_light = vec3(0.0, 0.0, 0.0);
	vec3 diffuse_light = vec3(0.0, 0.0, 0.0);
	vec3 ambient_light = vec3(0.0, 0.0, 0.0);

	vec3 eye_position = view;









	


	
	
	
	
	
	vec4 frag_color;



	ambient_light *= albedo;


	diffuse_light *= 1.0 - metallic;
	ambient_light *= 1.0 - metallic;

	frag_color = vec4(ambient_light + diffuse_light + specular_light, alpha);

	
	





	
	
	
	
	gl_FragColor = frag_color;

}

