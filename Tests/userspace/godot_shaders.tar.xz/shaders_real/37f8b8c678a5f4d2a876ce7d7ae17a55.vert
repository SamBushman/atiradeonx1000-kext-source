





vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2DLod(tex, vec2(x_coord, y_coord), 0.0);
}














 mat2 inverse( mat2 m) {
	 float d = 1.0 / (m[0].x * m[1].y - m[1].x * m[0].y);
	return mat2(
			vec2(m[1].y * d, -m[0].y * d),
			vec2(-m[1].x * d, m[0].x * d));
}

 mat3 inverse( mat3 m) {
	 float c01 = m[2].z * m[1].y - m[1].z * m[2].y;
	 float c11 = -m[2].z * m[1].x + m[1].z * m[2].x;
	 float c21 = m[2].y * m[1].x - m[1].y * m[2].x;
	 float d = 1.0 / (m[0].x * c01 + m[0].y * c11 + m[0].z * c21);

	return mat3(c01, (-m[2].z * m[0].y + m[0].z * m[2].y), (m[1].z * m[0].y - m[0].z * m[1].y),
				   c11, (m[2].z * m[0].x - m[0].z * m[2].x), (-m[1].z * m[0].x + m[0].z * m[1].x),
				   c21, (-m[2].y * m[0].x + m[0].y * m[2].x), (m[1].y * m[0].x - m[0].y * m[1].x)) *
			d;
}

 mat4 inverse( mat4 m) {
	 float c00 = m[2].z * m[3].w - m[3].z * m[2].w;
	 float c02 = m[1].z * m[3].w - m[3].z * m[1].w;
	 float c03 = m[1].z * m[2].w - m[2].z * m[1].w;

	 float c04 = m[2].y * m[3].w - m[3].y * m[2].w;
	 float c06 = m[1].y * m[3].w - m[3].y * m[1].w;
	 float c07 = m[1].y * m[2].w - m[2].y * m[1].w;

	 float c08 = m[2].y * m[3].z - m[3].y * m[2].z;
	 float c10 = m[1].y * m[3].z - m[3].y * m[1].z;
	 float c11 = m[1].y * m[2].z - m[2].y * m[1].z;

	 float c12 = m[2].x * m[3].w - m[3].x * m[2].w;
	 float c14 = m[1].x * m[3].w - m[3].x * m[1].w;
	 float c15 = m[1].x * m[2].w - m[2].x * m[1].w;

	 float c16 = m[2].x * m[3].z - m[3].x * m[2].z;
	 float c18 = m[1].x * m[3].z - m[3].x * m[1].z;
	 float c19 = m[1].x * m[2].z - m[2].x * m[1].z;

	 float c20 = m[2].x * m[3].y - m[3].x * m[2].y;
	 float c22 = m[1].x * m[3].y - m[3].x * m[1].y;
	 float c23 = m[1].x * m[2].y - m[2].x * m[1].y;

	vec4 f0 = vec4(c00, c00, c02, c03);
	vec4 f1 = vec4(c04, c04, c06, c07);
	vec4 f2 = vec4(c08, c08, c10, c11);
	vec4 f3 = vec4(c12, c12, c14, c15);
	vec4 f4 = vec4(c16, c16, c18, c19);
	vec4 f5 = vec4(c20, c20, c22, c23);

	vec4 v0 = vec4(m[1].x, m[0].x, m[0].x, m[0].x);
	vec4 v1 = vec4(m[1].y, m[0].y, m[0].y, m[0].y);
	vec4 v2 = vec4(m[1].z, m[0].z, m[0].z, m[0].z);
	vec4 v3 = vec4(m[1].w, m[0].w, m[0].w, m[0].w);

	vec4 inv0 = vec4(v1 * f0 - v2 * f1 + v3 * f2);
	vec4 inv1 = vec4(v0 * f0 - v2 * f3 + v3 * f4);
	vec4 inv2 = vec4(v0 * f1 - v1 * f3 + v3 * f5);
	vec4 inv3 = vec4(v0 * f2 - v1 * f4 + v2 * f5);

	vec4 sa = vec4(+1, -1, +1, -1);
	vec4 sb = vec4(-1, +1, -1, +1);

	mat4 inv = mat4(inv0 * sa, inv1 * sb, inv2 * sa, inv3 * sb);

	vec4 r0 = vec4(inv[0].x, inv[1].x, inv[2].x, inv[3].x);
	vec4 d0 = vec4(m[0] * r0);

	 float d1 = (d0.x + d0.y) + (d0.z + d0.w);
	 float d = 1.0 / d1;

	return inv * d;
}











 mat4 transpose( mat4 m) {
	return mat4(
			vec4(m[0].x, m[1].x, m[2].x, m[3].x),
			vec4(m[0].y, m[1].y, m[2].y, m[3].y),
			vec4(m[0].z, m[1].z, m[2].z, m[3].z),
			vec4(m[0].w, m[1].w, m[2].w, m[3].w));
}










attribute  vec4 vertex_attrib; 

attribute vec3 normal_attrib; 











uniform  mat4 camera_matrix;
uniform  mat4 camera_inverse_matrix;
uniform  mat4 projection_matrix;
uniform  mat4 projection_inverse_matrix;

uniform  mat4 world_transform;

uniform  float time;

uniform  vec2 viewport_size;


uniform  int view_index;







varying  vec3 vertex_interp;
varying vec3 normal_interp;







uniform  vec4 m_albedo;

mat3 m_orthonormalize(in mat3 m_m)
{
	vec3 m_x = normalize(m_m[0]);
	vec3 m_y = normalize((m_m[1] - (m_x * dot(m_x, m_m[1]))));
	vec3 m_z = (m_m[2] - (m_x * dot(m_x, m_m[2])));
	m_z = normalize((m_z - (m_y * dot(m_y, m_m[2]))));
	return mat3(m_x, m_y, m_z);
}









void main() {
	 vec4 vertex = vertex_attrib;

	mat4 world_matrix = world_transform;


	vec3 normal = normal_attrib;








	vec4 instance_custom = vec4(0.0);


	mat4 local_projection_matrix = projection_matrix;

	mat4 modelview = world_matrix;
	float roughness = 1.0;


	float point_size = 1.0;

	{
		
{
	mat3 m_mv = m_orthonormalize(mat3(modelview[0].xyz, modelview[1].xyz, modelview[2].xyz));
	m_mv = inverse(m_mv);
	vertex.xyz += (normal * 0.008);
	vec3 m_camera_dir_local = (m_mv * vec3(0.0,0.0,1.0));
	vec3 m_camera_up_local = (m_mv * vec3(0.0,1.0,0.0));
	mat3 m_rotation_matrix = mat3(cross(m_camera_dir_local, m_camera_up_local), m_camera_up_local, m_camera_dir_local);
	vertex.xyz = (m_rotation_matrix * vertex.xyz);
}


		
	}

	gl_PointSize = point_size;
	vec4 outvec = vertex;

	
	vertex = modelview * vertex;
	normal = normalize((modelview * vec4(normal, 0.0)).xyz);



	vertex_interp = vertex.xyz;
	normal_interp = normal;








	gl_Position = local_projection_matrix * vec4(vertex_interp, 1.0);


}



