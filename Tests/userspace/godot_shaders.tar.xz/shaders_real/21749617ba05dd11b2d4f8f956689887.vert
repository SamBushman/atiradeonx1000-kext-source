





vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2DLod(tex, vec2(x_coord, y_coord), 0.0);
}






















attribute  vec4 vertex_attrib; 

attribute vec3 normal_attrib; 











uniform  mat4 camera_matrix;
uniform  mat4 camera_inverse_matrix;
uniform  mat4 projection_matrix;
uniform  mat4 projection_inverse_matrix;

uniform  mat4 world_transform;

uniform  float time;

uniform  vec2 viewport_size;

uniform float light_bias;
uniform float light_normal_bias;

uniform  int view_index;






varying  vec4 position_interp;

varying  vec3 vertex_interp;
varying vec3 normal_interp;
















void main() {
	 vec4 vertex = vertex_attrib;

	mat4 world_matrix = world_transform;


	vec3 normal = normal_attrib;








	vec4 instance_custom = vec4(0.0);


	mat4 local_projection_matrix = projection_matrix;

	mat4 modelview = world_matrix;
	float roughness = 1.0;


	float point_size = 1.0;

	{
		


		
	}

	gl_PointSize = point_size;
	vec4 outvec = vertex;

	
	vertex = modelview * vertex;
	normal = normalize((modelview * vec4(normal, 0.0)).xyz);



	vertex_interp = vertex.xyz;
	normal_interp = normal;



	float z_ofs = light_bias;
	z_ofs += (1.0 - abs(normal_interp.z)) * light_normal_bias;

	vertex_interp.z -= z_ofs;







	gl_Position = local_projection_matrix * vec4(vertex_interp, 1.0);

	position_interp = gl_Position;

}



