







vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2D(tex,  vec2(x_coord, y_coord),  0.0);
}























 mat4 transpose( mat4 m) {
	return mat4(
			vec4(m[0].x, m[1].x, m[2].x, m[3].x),
			vec4(m[0].y, m[1].y, m[2].y, m[3].y),
			vec4(m[0].z, m[1].z, m[2].z, m[3].z),
			vec4(m[0].w, m[1].w, m[2].w, m[3].w));
}



uniform sampler2D color_texture; 

uniform  vec2 color_texpixel_size;
uniform  sampler2D normal_texture; 

varying  vec2 uv_interp;
varying  vec4 color_interp;

varying  vec4 modulate_interp;

uniform  float time;

uniform vec4 final_modulate;



const bool at_light_pass = false;

uniform bool use_default_normal;


uniform  vec4 m_fill_color;
uniform  vec4 m_shadow_color;
uniform  float m_shadow_dist;
uniform  float m_shadow_angle;
uniform  float m_shadow_offset;
uniform  vec2 m_uv_scale;
uniform  float m_samples;
const float m_TAU=6.28319;




void light_compute(
		inout vec4 light,
		inout vec2 light_vec,
		inout float light_height,
		inout vec4 light_color,
		vec2 light_uv,
		inout vec4 shadow_color,
		inout vec2 shadow_vec,
		vec3 normal,
		vec2 uv,
		vec4 color) {

}

void main() {
	vec4 color = color_interp;
	vec2 uv = uv_interp;



	vec3 normal;

	bool normal_used = false;

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	normal = vec3(0.0, 0.0, 1.0);

	{
		float normal_depth = 1.0;


		
		
		

		
{
	vec4 m_c = (texture2D(color_texture, uv) * m_fill_color);
	for (float m_i = 1.0; (m_i < (m_samples + 1.0)); m_i += 1.0)
{
	{
	float m_ang = ((m_shadow_angle + m_shadow_offset) * m_TAU);
	float m_f = (m_i / ceil(m_samples));
	vec4 m_s = texture2D(color_texture, (uv + (((vec2(sin(m_ang), cos(m_ang)) * m_uv_scale) * m_shadow_dist) * m_f)));
	m_c.rgb = mix(m_c.rgb, m_shadow_color.rgb, ((1.0 - m_s.a) * (1.0 / m_samples)));
}
;
}
	color = m_c;
}


		

	}

	color *= modulate_interp;



	gl_FragColor = color;
}

