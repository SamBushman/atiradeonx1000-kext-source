








vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2D(tex,  vec2(x_coord, y_coord),  0.0);
}














 mat2 inverse( mat2 m) {
	 float d = 1.0 / (m[0].x * m[1].y - m[1].x * m[0].y);
	return mat2(
			vec2(m[1].y * d, -m[0].y * d),
			vec2(-m[1].x * d, m[0].x * d));
}

 mat3 inverse( mat3 m) {
	 float c01 = m[2].z * m[1].y - m[1].z * m[2].y;
	 float c11 = -m[2].z * m[1].x + m[1].z * m[2].x;
	 float c21 = m[2].y * m[1].x - m[1].y * m[2].x;
	 float d = 1.0 / (m[0].x * c01 + m[0].y * c11 + m[0].z * c21);

	return mat3(c01, (-m[2].z * m[0].y + m[0].z * m[2].y), (m[1].z * m[0].y - m[0].z * m[1].y),
				   c11, (m[2].z * m[0].x - m[0].z * m[2].x), (-m[1].z * m[0].x + m[0].z * m[1].x),
				   c21, (-m[2].y * m[0].x + m[0].y * m[2].x), (m[1].y * m[0].x - m[0].y * m[1].x)) *
			d;
}

 mat4 inverse( mat4 m) {
	 float c00 = m[2].z * m[3].w - m[3].z * m[2].w;
	 float c02 = m[1].z * m[3].w - m[3].z * m[1].w;
	 float c03 = m[1].z * m[2].w - m[2].z * m[1].w;

	 float c04 = m[2].y * m[3].w - m[3].y * m[2].w;
	 float c06 = m[1].y * m[3].w - m[3].y * m[1].w;
	 float c07 = m[1].y * m[2].w - m[2].y * m[1].w;

	 float c08 = m[2].y * m[3].z - m[3].y * m[2].z;
	 float c10 = m[1].y * m[3].z - m[3].y * m[1].z;
	 float c11 = m[1].y * m[2].z - m[2].y * m[1].z;

	 float c12 = m[2].x * m[3].w - m[3].x * m[2].w;
	 float c14 = m[1].x * m[3].w - m[3].x * m[1].w;
	 float c15 = m[1].x * m[2].w - m[2].x * m[1].w;

	 float c16 = m[2].x * m[3].z - m[3].x * m[2].z;
	 float c18 = m[1].x * m[3].z - m[3].x * m[1].z;
	 float c19 = m[1].x * m[2].z - m[2].x * m[1].z;

	 float c20 = m[2].x * m[3].y - m[3].x * m[2].y;
	 float c22 = m[1].x * m[3].y - m[3].x * m[1].y;
	 float c23 = m[1].x * m[2].y - m[2].x * m[1].y;

	vec4 f0 = vec4(c00, c00, c02, c03);
	vec4 f1 = vec4(c04, c04, c06, c07);
	vec4 f2 = vec4(c08, c08, c10, c11);
	vec4 f3 = vec4(c12, c12, c14, c15);
	vec4 f4 = vec4(c16, c16, c18, c19);
	vec4 f5 = vec4(c20, c20, c22, c23);

	vec4 v0 = vec4(m[1].x, m[0].x, m[0].x, m[0].x);
	vec4 v1 = vec4(m[1].y, m[0].y, m[0].y, m[0].y);
	vec4 v2 = vec4(m[1].z, m[0].z, m[0].z, m[0].z);
	vec4 v3 = vec4(m[1].w, m[0].w, m[0].w, m[0].w);

	vec4 inv0 = vec4(v1 * f0 - v2 * f1 + v3 * f2);
	vec4 inv1 = vec4(v0 * f0 - v2 * f3 + v3 * f4);
	vec4 inv2 = vec4(v0 * f1 - v1 * f3 + v3 * f5);
	vec4 inv3 = vec4(v0 * f2 - v1 * f4 + v2 * f5);

	vec4 sa = vec4(+1, -1, +1, -1);
	vec4 sb = vec4(-1, +1, -1, +1);

	mat4 inv = mat4(inv0 * sa, inv1 * sb, inv2 * sa, inv3 * sb);

	vec4 r0 = vec4(inv[0].x, inv[1].x, inv[2].x, inv[3].x);
	vec4 d0 = vec4(m[0] * r0);

	 float d1 = (d0.x + d0.y) + (d0.z + d0.w);
	 float d = 1.0 / d1;

	return inv * d;
}








uniform  mat4 camera_matrix;

uniform  mat4 camera_inverse_matrix;
uniform  mat4 projection_matrix;
uniform  mat4 projection_inverse_matrix;

uniform  mat4 world_transform;

uniform  float time;
uniform  int view_index;

uniform  vec2 viewport_size;










uniform vec4 bg_color;
uniform float bg_energy;

uniform float ambient_sky_contribution;
uniform vec4 ambient_color;
uniform float ambient_energy;







varying  vec3 vertex_interp;
varying vec3 normal_interp;





varying vec3 view_interp;

vec3 F0(float metallic, float specular, vec3 albedo) {
	float dielectric = 0.16 * specular * specular;
	
	
	return mix(vec3(dielectric), albedo, vec3(metallic));
}


uniform  vec4 m_albedo;









void main() {
	 vec3 vertex = vertex_interp;
	vec3 view = -normalize(vertex_interp);
	vec3 albedo = vec3(1.0);
	vec3 transmission = vec3(0.0);
	float metallic = 0.0;
	float specular = 0.5;
	vec3 emission = vec3(0.0);
	float roughness = 1.0;
	float rim = 0.0;
	float rim_tint = 0.0;
	float clearcoat = 0.0;
	float clearcoat_gloss = 0.0;
	float anisotropy = 0.0;
	vec2 anisotropy_flow = vec2(1.0, 0.0);
	float sss_strength = 0.0; 
	
	
	float m_DEPTH = 0.0;

	float alpha = 1.0;
	float side = 1.0;

	float specular_blob_intensity = 1.0;


	vec3 binormal = vec3(0.0);
	vec3 tangent = vec3(0.0);
	vec3 normal = normalize(normal_interp) * side;

	float normaldepth = 1.0;



	{
		
{
	albedo = m_albedo.rgb;
	alpha = m_albedo.a;
}


		
	}


	normal = normalize(normal);

	vec3 N = normal;

	vec3 specular_light = vec3(0.0, 0.0, 0.0);
	vec3 diffuse_light = vec3(0.0, 0.0, 0.0);
	vec3 ambient_light = vec3(0.0, 0.0, 0.0);

	vec3 eye_position = view;









	


	
	
	
	
	
	vec4 frag_color;



	ambient_light *= albedo;


	diffuse_light *= 1.0 - metallic;
	ambient_light *= 1.0 - metallic;

	frag_color = vec4(ambient_light + diffuse_light + specular_light, alpha);

	
	





	
	
	
	
	gl_FragColor = frag_color;

}

