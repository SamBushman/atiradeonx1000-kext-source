






uniform sampler2D source_panorama; 


uniform int face_id;
uniform float roughness;
varying  vec2 uv_interp;

uniform sampler2D radical_inverse_vdc_cache; 






vec4 texturePanorama(sampler2D pano, vec3 normal) {
	vec2 st = vec2(
			atan(normal.x, normal.z),
			acos(normal.y));

	if (st.x < 0.0)
		st.x += 3.14159265359 * 2.0;

	st /= vec2(3.14159265359 * 2.0, 3.14159265359);

	return texture2D(pano,  st,  0.0);
}


vec3 texelCoordToVec(vec2 uv, int faceID) {
	mat3 faceUvVectors[6];

	
	faceUvVectors[0][0] = vec3(0.0, 0.0, 1.0); 
	faceUvVectors[0][1] = vec3(0.0, -1.0, 0.0); 
	faceUvVectors[0][2] = vec3(-1.0, 0.0, 0.0); 

	
	faceUvVectors[1][0] = vec3(0.0, 0.0, -1.0); 
	faceUvVectors[1][1] = vec3(0.0, -1.0, 0.0); 
	faceUvVectors[1][2] = vec3(1.0, 0.0, 0.0); 

	
	faceUvVectors[2][0] = vec3(1.0, 0.0, 0.0); 
	faceUvVectors[2][1] = vec3(0.0, 0.0, -1.0); 
	faceUvVectors[2][2] = vec3(0.0, -1.0, 0.0); 

	
	faceUvVectors[3][0] = vec3(1.0, 0.0, 0.0); 
	faceUvVectors[3][1] = vec3(0.0, 0.0, 1.0); 
	faceUvVectors[3][2] = vec3(0.0, 1.0, 0.0); 

	
	faceUvVectors[4][0] = vec3(-1.0, 0.0, 0.0); 
	faceUvVectors[4][1] = vec3(0.0, -1.0, 0.0); 
	faceUvVectors[4][2] = vec3(0.0, 0.0, -1.0); 

	
	faceUvVectors[5][0] = vec3(1.0, 0.0, 0.0); 
	faceUvVectors[5][1] = vec3(0.0, -1.0, 0.0); 
	faceUvVectors[5][2] = vec3(0.0, 0.0, 1.0); 

	
	vec3 result;
	for (int i = 0; i < 6; i++) {
		if (i == faceID) {
			result = (faceUvVectors[i][0] * uv.x) + (faceUvVectors[i][1] * uv.y) + faceUvVectors[i][2];
			break;
		}
	}
	return normalize(result);
}

vec3 ImportanceSampleGGX(vec2 Xi, float Roughness, vec3 N) {
	float a = Roughness * Roughness; 

	
	float Phi = 2.0 * 3.14159265359 * Xi.x;
	float CosTheta = sqrt((1.0 - Xi.y) / (1.0 + (a * a - 1.0) * Xi.y));
	float SinTheta = sqrt(1.0 - CosTheta * CosTheta);

	
	vec3 H;
	H.x = SinTheta * cos(Phi);
	H.y = SinTheta * sin(Phi);
	H.z = CosTheta;

	vec3 UpVector = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
	vec3 TangentX = normalize(cross(UpVector, N));
	vec3 TangentY = cross(N, TangentX);

	
	return TangentX * H.x + TangentY * H.y + N * H.z;
}

float radical_inverse_VdC(int i) {
	return texture2D(radical_inverse_vdc_cache, vec2(float(i) / 512.0, 0.0)).x;
}

vec2 Hammersley(int i, int N) {
	return vec2(float(i) / float(N), radical_inverse_VdC(i));
}

uniform bool z_flip;

void main() {
	vec3 color = vec3(0.0);

	vec2 uv = (uv_interp * 2.0) - 1.0;
	vec3 N = texelCoordToVec(uv, face_id);


	vec4 sum = vec4(0.0);

	for (int sample_num = 0; sample_num < 64; sample_num++) {
		vec2 xi = Hammersley(sample_num, 64);

		vec3 H = ImportanceSampleGGX(xi, roughness, N);
		vec3 V = N;
		vec3 L = (2.0 * dot(V, H) * H - V);

		float NdotL = clamp(dot(N, L), 0.0, 1.0);

		if (NdotL > 0.0) {

			vec3 val = texturePanorama(source_panorama, L).rgb;
			
			val = mix(pow((val + vec3(0.055)) * (1.0 / (1.0 + 0.055)), vec3(2.4)), val * (1.0 / 12.92), vec3(lessThan(val, vec3(0.04045))));

			sum.rgb += val * NdotL;

			sum.a += NdotL;
		}
	}

	sum /= sum.a;

	vec3 a = vec3(0.055);
	sum.rgb = mix((vec3(1.0) + a) * pow(sum.rgb, vec3(1.0 / 2.4)) - a, 12.92 * sum.rgb, vec3(lessThan(sum.rgb, vec3(0.0031308))));

	gl_FragColor = vec4(sum.rgb, 1.0);
}

