







vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2D(tex,  vec2(x_coord, y_coord),  0.0);
}















uniform sampler2D color_texture; 

uniform  vec2 color_texpixel_size;
uniform  sampler2D normal_texture; 

varying  vec2 uv_interp;
varying  vec4 color_interp;


uniform  float time;

uniform vec4 final_modulate;


uniform sampler2D screen_texture; 



uniform vec2 screen_pixel_size;


const bool at_light_pass = false;

uniform bool use_default_normal;


uniform  float m_blur_angle;
uniform  float m_blur_offset;
uniform  float m_steps;
uniform  float m_aspect;




void light_compute(
		inout vec4 light,
		inout vec2 light_vec,
		inout float light_height,
		inout vec4 light_color,
		vec2 light_uv,
		inout vec4 shadow_color,
		inout vec2 shadow_vec,
		vec3 normal,
		vec2 uv,
		vec2 screen_uv,
		vec4 color) {

}

void main() {
	vec4 color = color_interp;
	vec2 uv = uv_interp;


	vec2 screen_uv = gl_FragCoord.xy * screen_pixel_size;

	vec3 normal;

	bool normal_used = false;

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	normal = vec3(0.0, 0.0, 1.0);

	{
		float normal_depth = 1.0;


		
		
		

		
{
	vec2 m_uv = screen_uv;
	m_uv.y *= m_aspect;
	vec2 m_center = vec2(0.5, (0.5 * m_aspect));
	float m_angle = atan((m_uv.y - m_center.y), (m_uv.x - m_center.x));
	float m_dist = distance(m_uv, m_center);
	vec3 m_color = vec3(0.0,0.0,0.0);
	for (float m_i = 0.0; (m_i < m_steps); m_i += 1.0)
{
	{
	float m_dus_angle = ((m_angle + (m_blur_angle * m_blur_offset)) + mix(-m_blur_angle, m_blur_angle, (m_i / ceil(m_steps))));
	vec2 m_tuv = ((vec2(cos(m_dus_angle), sin(m_dus_angle)) * m_dist) + m_center);
	m_tuv.y /= m_aspect;
	m_color += (texture2D(screen_texture, m_tuv).rgb / ceil(m_steps));
}
;
}
	color.rgb = m_color;
}


		

	}

	color *= final_modulate;



	gl_FragColor = color;
}

