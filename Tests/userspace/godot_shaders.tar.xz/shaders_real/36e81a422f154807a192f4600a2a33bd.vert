

uniform  mat4 projection_matrix;



vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2DLod(tex, vec2(x_coord, y_coord), 0.0);
}















uniform  mat4 modelview_matrix;
uniform  mat4 extra_matrix;
attribute  vec2 vertex; 


attribute vec4 color_attrib; 
attribute vec2 uv_attrib; 












varying vec2 uv_interp;
varying vec4 color_interp;



uniform  vec2 color_texpixel_size;


uniform  float time;

const bool at_light_pass = false;


uniform  vec4 m_add_color;




vec2 select(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

void main() {
	vec4 color = color_attrib;
	vec2 uv;

	mat4 extra_matrix_instance = extra_matrix;







	vec4 instance_custom = vec4(0.0);

	vec4 outvec = vec4(vertex.xy, 0.0, 1.0);

	uv = uv_attrib;

	float point_size = 1.0;

	{
		vec2 src_vtx = outvec.xy;
		


		
	}

	gl_PointSize = point_size;



	
	outvec = extra_matrix_instance * outvec;
	outvec = modelview_matrix * outvec;


	color_interp = color;



	uv_interp = uv;
	gl_Position = projection_matrix * outvec;

}



