





vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2DLod(tex, vec2(x_coord, y_coord), 0.0);
}






















attribute  vec4 vertex_attrib; 

attribute vec4 normal_tangent_attrib; 



attribute vec2 uv_attrib; 








uniform  mat4 camera_matrix;
uniform  mat4 camera_inverse_matrix;
uniform  mat4 projection_matrix;
uniform  mat4 projection_inverse_matrix;

uniform  mat4 world_transform;

uniform  float time;

uniform  vec2 viewport_size;


uniform  int view_index;

vec3 oct_to_vec3(vec2 e) {
	vec3 v = vec3(e.xy, 1.0 - abs(e.x) - abs(e.y));
	float t = max(-v.z, 0.0);
	v.xy += t * -sign(v.xy);
	return normalize(v);
}






varying  vec3 vertex_interp;
varying vec3 normal_interp;



varying vec2 uv_interp;



uniform  vec4 m_albedo;
uniform  sampler2D m_texture_albedo;
uniform  float m_specular;
uniform  float m_metallic;
uniform  float m_roughness;
uniform  float m_point_size;
uniform  sampler2D m_texture_emission;
uniform  vec4 m_emission;
uniform  float m_emission_energy;
uniform  vec3 m_uv1_scale;
uniform  vec3 m_uv1_offset;
uniform  vec3 m_uv2_scale;
uniform  vec3 m_uv2_offset;









void main() {
	 vec4 vertex = vertex_attrib;

	mat4 world_matrix = world_transform;


	vec3 normal = oct_to_vec3(normal_tangent_attrib.xy);



	uv_interp = uv_attrib;





	vec4 instance_custom = vec4(0.0);


	mat4 local_projection_matrix = projection_matrix;

	mat4 modelview = world_matrix;
	float roughness = 1.0;


	float point_size = 1.0;

	{
		
{
	uv_interp = ((uv_interp * m_uv1_scale.xy) + m_uv1_offset.xy);
}


		
	}

	gl_PointSize = point_size;
	vec4 outvec = vertex;

	
	vertex = modelview * vertex;
	normal = normalize((modelview * vec4(normal, 0.0)).xyz);



	vertex_interp = vertex.xyz;
	normal_interp = normal;








	gl_Position = local_projection_matrix * vec4(vertex_interp, 1.0);

}



