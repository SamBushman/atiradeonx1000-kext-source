





vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2DLod(tex, vec2(x_coord, y_coord), 0.0);
}






















attribute  vec4 vertex_attrib; 

attribute vec4 normal_tangent_attrib; 











uniform  mat4 camera_matrix;
uniform  mat4 camera_inverse_matrix;
uniform  mat4 projection_matrix;
uniform  mat4 projection_inverse_matrix;

uniform  mat4 world_transform;

uniform  float time;

uniform  vec2 viewport_size;


uniform  int view_index;

vec3 oct_to_vec3(vec2 e) {
	vec3 v = vec3(e.xy, 1.0 - abs(e.x) - abs(e.y));
	float t = max(-v.z, 0.0);
	v.xy += t * -sign(v.xy);
	return normalize(v);
}






varying  vec3 vertex_interp;
varying vec3 normal_interp;






uniform  vec4 m_albedo;

mat3 m_orthonormalize(in mat3 m_m)
{
	vec3 m_x = normalize(m_m[0]);
	vec3 m_y = normalize((m_m[1] - (m_x * dot(m_x, m_m[1]))));
	vec3 m_z = (m_m[2] - (m_x * dot(m_x, m_m[2])));
	m_z = normalize((m_z - (m_y * dot(m_y, m_m[2]))));
	return mat3(m_x, m_y, m_z);
}









void main() {
	 vec4 vertex = vertex_attrib;

	mat4 world_matrix = world_transform;


	vec3 normal = oct_to_vec3(normal_tangent_attrib.xy);








	vec4 instance_custom = vec4(0.0);


	mat4 local_projection_matrix = projection_matrix;

	mat4 modelview = world_matrix;
	float roughness = 1.0;


	float point_size = 1.0;

	{
		
{
	mat3 m_mv = m_orthonormalize(mat3(modelview[0].xyz, modelview[1].xyz, modelview[2].xyz));
	vec3 m_n = (m_mv * vertex.xyz);
	float m_orientation = dot(vec3(0.0,0.0,-1.0), m_n);
	if ((m_orientation <= 0.005))
	{
			{
		vertex.xyz += (normal * 0.02);
	}
;
	}
}


		
	}

	gl_PointSize = point_size;
	vec4 outvec = vertex;

	
	vertex = modelview * vertex;
	normal = normalize((modelview * vec4(normal, 0.0)).xyz);



	vertex_interp = vertex.xyz;
	normal_interp = normal;








	gl_Position = local_projection_matrix * vec4(vertex_interp, 1.0);

}



