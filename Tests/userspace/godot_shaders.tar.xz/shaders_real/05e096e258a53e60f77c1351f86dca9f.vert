

uniform  mat4 projection_matrix;



vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2DLod(tex, vec2(x_coord, y_coord), 0.0);
}























 mat4 transpose( mat4 m) {
	return mat4(
			vec4(m[0].x, m[1].x, m[2].x, m[3].x),
			vec4(m[0].y, m[1].y, m[2].y, m[3].y),
			vec4(m[0].z, m[1].z, m[2].z, m[3].z),
			vec4(m[0].w, m[1].w, m[2].w, m[3].w));
}



uniform  mat4 modelview_matrix;
uniform  mat4 extra_matrix;
attribute  vec2 vertex; 


attribute vec4 color_attrib; 
attribute vec2 uv_attrib; 











attribute  vec4 instance_xform0; 
attribute  vec4 instance_xform1; 
attribute  vec4 instance_xform2; 
attribute  vec4 instance_color; 




varying vec2 uv_interp;
varying vec4 color_interp;



uniform  vec2 color_texpixel_size;


uniform  float time;

const bool at_light_pass = false;






vec2 select(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

void main() {
	vec4 color = color_attrib;
	vec2 uv;

	mat4 extra_matrix_instance = extra_matrix * transpose(mat4(instance_xform0, instance_xform1, instance_xform2, vec4(0.0, 0.0, 0.0, 1.0)));
	color *= instance_color;







	vec4 instance_custom = vec4(0.0);

	vec4 outvec = vec4(vertex.xy, 0.0, 1.0);

	uv = uv_attrib;

	float point_size = 1.0;

	{
		vec2 src_vtx = outvec.xy;
		


		
	}

	gl_PointSize = point_size;



	
	outvec = extra_matrix_instance * outvec;
	outvec = modelview_matrix * outvec;


	color_interp = color;



	uv_interp = uv;
	gl_Position = projection_matrix * outvec;

}



