

uniform  mat4 projection_matrix;



vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2DLod(tex, vec2(x_coord, y_coord), 0.0);
}















uniform  mat4 modelview_matrix;
uniform  mat4 extra_matrix;
attribute  vec2 vertex; 


attribute vec4 color_attrib; 
attribute vec2 uv_attrib; 












varying vec2 uv_interp;
varying vec4 color_interp;



uniform  vec2 color_texpixel_size;


uniform vec4 dst_rect;
uniform vec4 src_rect;


uniform  float time;

const bool at_light_pass = false;


uniform  float m_height;
uniform  float m_fade_height;
uniform  float m_scale_x;
uniform  float m_scale_y;
uniform  float m_time_scale;
uniform  sampler2D m_tread_mask;
uniform  sampler2D m_box_mask;




vec2 select(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

void main() {
	vec4 color = color_attrib;
	vec2 uv;

	mat4 extra_matrix_instance = extra_matrix;







	vec4 instance_custom = vec4(0.0);


	if (dst_rect.z < 0.0) { 
		uv = src_rect.xy + abs(src_rect.zw) * vertex.yx;
	} else {
		uv = src_rect.xy + abs(src_rect.zw) * vertex;
	}

	vec4 outvec = vec4(0.0, 0.0, 0.0, 1.0);

	
	
	
	
	

	outvec.xy = dst_rect.xy + abs(dst_rect.zw) * select(vertex, vec2(1.0, 1.0) - vertex, lessThan(src_rect.zw, vec2(0.0, 0.0)));

	

	float point_size = 1.0;

	{
		vec2 src_vtx = outvec.xy;
		


		
	}

	gl_PointSize = point_size;



	
	outvec = extra_matrix_instance * outvec;
	outvec = modelview_matrix * outvec;


	color_interp = color;



	uv_interp = uv;
	gl_Position = projection_matrix * outvec;

}



