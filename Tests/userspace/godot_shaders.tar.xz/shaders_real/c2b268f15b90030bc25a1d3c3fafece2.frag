








vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2D(tex,  vec2(x_coord, y_coord),  0.0);
}




















uniform  mat4 camera_matrix;

uniform  mat4 camera_inverse_matrix;
uniform  mat4 projection_matrix;
uniform  mat4 projection_inverse_matrix;

uniform  mat4 world_transform;

uniform  float time;
uniform  int view_index;

uniform  vec2 viewport_size;










uniform vec4 bg_color;
uniform float bg_energy;

uniform float ambient_sky_contribution;
uniform vec4 ambient_color;
uniform float ambient_energy;


uniform  vec4 shadow_color;



uniform  vec4 light_color;

uniform  float light_specular;


uniform  vec3 light_direction;

uniform  vec3 light_position;

uniform  float light_attenuation;


uniform  float light_spot_attenuation;
uniform  float light_spot_range;
uniform  float light_spot_angle;


uniform  float light_range;










varying  vec3 vertex_interp;
varying vec3 normal_interp;






varying vec3 view_interp;

vec3 F0(float metallic, float specular, vec3 albedo) {
	float dielectric = 0.16 * specular * specular;
	
	
	return mix(vec3(dielectric), albedo, vec3(metallic));
}









































float V_GGX(float cos_theta_l, float cos_theta_v, float alpha) {
	return 0.5 / mix(2.0 * cos_theta_l * cos_theta_v, cos_theta_l + cos_theta_v, alpha);
}

float D_GGX(float cos_theta_m, float alpha) {
	float alpha2 = alpha * alpha;
	float d = 1.0 + (alpha2 - 1.0) * cos_theta_m * cos_theta_m;
	return alpha2 / (3.14159265359 * d * d);
}













float V_GGX_anisotropic(float alpha_x, float alpha_y, float TdotV, float TdotL, float BdotV, float BdotL, float NdotV, float NdotL) {
	float Lambda_V = NdotL * length(vec3(alpha_x * TdotV, alpha_y * BdotV, NdotV));
	float Lambda_L = NdotV * length(vec3(alpha_x * TdotL, alpha_y * BdotL, NdotL));
	return 0.5 / (Lambda_V + Lambda_L);
}

float D_GGX_anisotropic(float cos_theta_m, float alpha_x, float alpha_y, float cos_phi, float sin_phi, float NdotH) {
	float alpha2 = alpha_x * alpha_y;
	 vec3 v = vec3(alpha_y * cos_phi, alpha_x * sin_phi, alpha2 * NdotH);
	 float v2 = dot(v, v);
	float w2 = alpha2 / v2;
	float D = alpha2 * w2 * w2 * (1.0 / 3.14159265359);
	return D;

	





}

float SchlickFresnel(float u) {
	float m = 1.0 - u;
	float m2 = m * m;
	return m2 * m2 * m; 
}

float GTR1(float NdotH, float a) {
	if (a >= 1.0)
		return 1.0 / 3.14159265359;
	float a2 = a * a;
	float t = 1.0 + (a2 - 1.0) * NdotH * NdotH;
	return (a2 - 1.0) / (3.14159265359 * log(a2) * t);
}


void light_compute(
		vec3 N,
		vec3 L,
		vec3 V,
		vec3 B,
		vec3 T,
		vec3 light_color,
		vec3 attenuation,
		vec3 diffuse_color,
		vec3 transmission,
		float specular_blob_intensity,
		float roughness,
		float metallic,
		float specular,
		float rim,
		float rim_tint,
		float clearcoat,
		float clearcoat_gloss,
		float anisotropy,
		inout vec3 diffuse_light,
		inout vec3 specular_light,
		inout float alpha) {













	float NdotL = dot(N, L);
	float cNdotL = max(NdotL, 0.0); 
	float NdotV = dot(N, V);
	float cNdotV = max(abs(NdotV), 1e-6);



	vec3 H = normalize(V + L);

	float cNdotH = max(dot(N, H), 0.0);

	float cLdotH = max(dot(L, H), 0.0);

	if (metallic < 1.0) {
		float diffuse_brdf_NL; 

		
		diffuse_brdf_NL = cNdotL * (1.0 / 3.14159265359);

		

		diffuse_light += light_color * diffuse_color * diffuse_brdf_NL * attenuation;


	}

	if (roughness > 0.0) {

		vec3 specular_brdf_NL = vec3(0.0);

		

		float alpha_ggx = roughness * roughness;
		float D = D_GGX(cNdotH, alpha_ggx);
		
		float G = V_GGX(cNdotL, cNdotV, alpha_ggx);
		
		vec3 f0 = F0(metallic, specular, diffuse_color);
		float cLdotH5 = SchlickFresnel(cLdotH);
		vec3 F = mix(vec3(cLdotH5), vec3(1.0), f0);

		specular_brdf_NL = cNdotL * D * F * G;


		
		specular_light += specular_brdf_NL * light_color * specular_blob_intensity * attenuation;

	}


}





void main() {
	 vec3 vertex = vertex_interp;
	vec3 view = -normalize(vertex_interp);
	vec3 albedo = vec3(1.0);
	vec3 transmission = vec3(0.0);
	float metallic = 0.0;
	float specular = 0.5;
	vec3 emission = vec3(0.0);
	float roughness = 1.0;
	float rim = 0.0;
	float rim_tint = 0.0;
	float clearcoat = 0.0;
	float clearcoat_gloss = 0.0;
	float anisotropy = 0.0;
	vec2 anisotropy_flow = vec2(1.0, 0.0);
	float sss_strength = 0.0; 
	
	
	float m_DEPTH = 0.0;

	float alpha = 1.0;
	float side = 1.0;

	float specular_blob_intensity = 1.0;


	vec3 binormal = vec3(0.0);
	vec3 tangent = vec3(0.0);
	vec3 normal = normalize(normal_interp) * side;

	float normaldepth = 1.0;




	{
		


		
	}


	normal = normalize(normal);

	vec3 N = normal;

	vec3 specular_light = vec3(0.0, 0.0, 0.0);
	vec3 diffuse_light = vec3(0.0, 0.0, 0.0);
	vec3 ambient_light = vec3(0.0, 0.0, 0.0);

	vec3 eye_position = view;










	vec3 L;
	vec3 light_att = vec3(1.0);



	vec3 light_vec = -light_direction;
	L = normalize(light_vec);
	float depth_z = -vertex.z;






	
	light_compute(
			normal,
			L,
			eye_position,
			binormal,
			tangent,
			light_color.xyz,
			light_att,
			albedo,
			transmission,
			specular_blob_intensity * light_specular,
			roughness,
			metallic,
			specular,
			rim,
			rim_tint,
			clearcoat,
			clearcoat_gloss,
			anisotropy,
			diffuse_light,
			specular_light,
			alpha);


	


	
	
	
	
	
	vec4 frag_color;



	ambient_light *= albedo;


	diffuse_light *= 1.0 - metallic;
	ambient_light *= 1.0 - metallic;

	frag_color = vec4(ambient_light + diffuse_light + specular_light, alpha);

	
	





	
	
	
	
	gl_FragColor = frag_color;

}

