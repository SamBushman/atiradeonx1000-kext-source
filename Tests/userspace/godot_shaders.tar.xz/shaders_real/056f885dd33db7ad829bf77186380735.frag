







vec2 select2(vec2 a, vec2 b, bvec2 c) {
	vec2 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;

	return ret;
}

vec3 select3(vec3 a, vec3 b, bvec3 c) {
	vec3 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;

	return ret;
}

vec4 select4(vec4 a, vec4 b, bvec4 c) {
	vec4 ret;

	ret.x = c.x ? b.x : a.x;
	ret.y = c.y ? b.y : a.y;
	ret.z = c.z ? b.z : a.z;
	ret.w = c.w ? b.w : a.w;

	return ret;
}

 vec4 texel2DFetch( sampler2D tex, ivec2 size, ivec2 coord) {
	float x_coord = float(2 * coord.x + 1) / float(size.x * 2);
	float y_coord = float(2 * coord.y + 1) / float(size.y * 2);

	return texture2D(tex,  vec2(x_coord, y_coord),  0.0);
}















uniform sampler2D color_texture; 

uniform  vec2 color_texpixel_size;
uniform  sampler2D normal_texture; 

varying  vec2 uv_interp;
varying  vec4 color_interp;


uniform  float time;

uniform vec4 final_modulate;



uniform vec2 screen_pixel_size;


const bool at_light_pass = false;

uniform bool use_default_normal;


uniform  vec2 m_point;
uniform  float m_radius;
uniform  vec4 m_outside_color;
uniform  vec4 m_inside_color;
uniform  vec4 m_sun_color;
uniform  vec4 m_col1;
uniform  vec4 m_col2;
uniform  float m_sun_frac;
uniform  float m_time_scale;
uniform  float m_time_add;

vec3 m_blendAddy(in vec3 m_base, in vec3 m_blend)
{
	return min((m_base + m_blend), vec3(1.0,1.0,1.0));
}

vec3 m_blendAdd(in vec3 m_base, in vec3 m_blend, in float m_opacity)
{
	return ((m_blendAddy(m_base, m_blend) * m_opacity) + (m_base * (1.0 - m_opacity)));
}




void light_compute(
		inout vec4 light,
		inout vec2 light_vec,
		inout float light_height,
		inout vec4 light_color,
		vec2 light_uv,
		inout vec4 shadow_color,
		inout vec2 shadow_vec,
		vec3 normal,
		vec2 uv,
		vec2 screen_uv,
		vec4 color) {

}

void main() {
	vec4 color = color_interp;
	vec2 uv = uv_interp;


	vec2 screen_uv = gl_FragCoord.xy * screen_pixel_size;

	vec3 normal;

	bool normal_used = false;

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	normal = vec3(0.0, 0.0, 1.0);

	{
		float normal_depth = 1.0;


		
		
		

		
{
	vec4 m_c = mix(m_col2, m_col1, screen_uv.y);
	float m_f = (mod((m_time_add + (time * m_time_scale)), 2.0) - 0.5);
	vec4 m_nc = mix(m_outside_color, m_inside_color, float((distance(vec2(m_f, 0.5), uv) < m_radius)));
	color = mix(vec4(m_blendAdd(m_c.rgb, m_nc.rgb, m_nc.a), 1.0), m_sun_color, m_sun_frac);
}


		

	}

	color *= final_modulate;



	gl_FragColor = color;
}

